Please see our contributor documentation at
https://firefox-source-docs.mozilla.org/testing/geckodriver/#for-developers.
